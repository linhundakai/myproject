package com.netflix.hystrix.contrib.javanica.annotation;

/**
 * Created by Mike Cowan
 */
public enum HystrixException {
    RUNTIME_EXCEPTION,
}
